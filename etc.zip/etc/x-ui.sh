clear
echo -e " Do you want to install x-ui ?
bash <(curl -Ls https://raw.githubusercontent.com/X-UI-Unofficial/release/main/install.sh) 221120_v5
sleep 5
bash menu.sh