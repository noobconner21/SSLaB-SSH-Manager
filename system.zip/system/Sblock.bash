#!/bin/bash
#Scripiter Penguin
#
bmenu(){
FILE3=/etc/blockdragon
if [ -d "$FILE3" ]; then
clear
else
sudo mkdir /etc/blockdragon
chmod 777 /etc/blockdragon
fi
FILE4=/etc/blockdragon/blocks
if [ -d "$FILE4" ]; then
clear
else
sudo mkdir /etc/blockdragon/blocks
chmod 777 /etc/blockdragon/blocks
fi
FILE=/etc/blockdragon/sites.cake
if [ -f "$FILE" ]; then
clear
else
sudo touch /etc/blockdragon/sites.cake
fi
FILE2=/etc/blockdragon/dragon.block
if [ -f "$FILE2" ]; then
clear
else
sudo touch /etc/blockdragon/dragon.block
fi
black='\033[0;30m'
red='\033[0;31m'
green='\033[0;32m'
browno='\033[0;33m'
blue='\033[0;34m'
purple='\033[0;35m'
cyan='\033[0;36m'
lightgray='\033[0;37m'
darkgray='\033[1;30m'
lightred='\033[1;31m'
lightgreen='\033[1;32m'
yellow='\033[1;33m'
lightblue='\033[1;34m'
lightpurple='\033[1;35m'
lightcyan='\033[1;36m'
white='\033[1;37m'
clear
clear
echo -e "          ░█▀▀▀█ ░█▀▀▀█ ░█─── ─█▀▀█ ░█▀▀█ 　 ░█▀▀▀█ ░█▀▀▀█ ░█─░█ " | lolcat
echo -e "          ─▀▀▀▄▄ ─▀▀▀▄▄ ░█─── ░█▄▄█ ░█▀▀▄ 　 ─▀▀▀▄▄ ─▀▀▀▄▄ ░█▀▀█ " | lolcat
echo -e "          ░█▄▄▄█ ░█▄▄▄█ ░█▄▄█ ░█─░█ ░█▄▄█ 　 ░█▄▄▄█ ░█▄▄▄█ ░█─░█ " | lolcat
echo ""
echo ""

echo -e  "${lightblue}           === ● Main Menu ● === "
echo ""
echo -e  "${red} =============================="
echo ""
tput setaf 2 ; tput bold ; printf '%s' "|1|"; tput setaf 6 ; printf '%s' " Block Website" ; echo ""
tput setaf 2 ; tput bold ; printf '%s' "|2|"; tput setaf 6 ; printf '%s' " View List" ;  echo ""
tput setaf 2 ; tput bold ; printf '%s' "|3|"; tput setaf 6 ; printf '%s' " Unblock Website" ;  echo ""
tput setaf 2 ; tput bold ; printf '%s' "|4|"; tput setaf 6 ; printf '%s' " Unblock ALL" ;  echo ""
tput setaf 2 ; tput bold ; printf '%s' "|5|"; tput setaf 6 ; printf '%s' " Reblock ALL (IF the server is rebooted) " ;  echo ""
tput setaf 2 ; tput bold ; printf '%s' "|6|"; tput setaf 6 ; printf '%s' " SSH Menu" ;  echo ""
echo ""
echo -e "${red} =============================="
echo ""
echo -e "${green} Select a Option :" ; tput sgr0 ; echo ""
echo -n "> "
read  opcao 
case $opcao in
	1) block ;;
	2) view ;;
	3) unblock ;;
	4) unblockall ;;
	5) reblockall ;;
	6) mmenu ;;
esac
bmenu
}

block(){
clear
echo -e " ${yellow}         === • BLOCKER • ===" ; tput sgr0 ; echo ""
echo ""
tput setaf 2 ; tput bold ; printf '%s' "|1|"; tput setaf 6 ; printf '%s' " Block" ; echo ""
tput setaf 2 ; tput bold ; printf '%s' "|2|"; tput setaf 6 ; printf '%s' " Back to menu" ; echo ""
echo ""
echo "Select a Option" ; tput sgr0 ; echo ""
echo -n "> "
read option
if [ "$option" = "1" ]; then 
clear
echo ""
tput setaf 2 ; tput bold ; printf '%s' "[>]"; tput setaf 6 ; printf '%s' " Insert the Website" ; tput setaf 2 ; tput bold ; printf '%s' " ="; echo ""
echo ""
echo -n "> "
read website
if [ -z $website ]; then
clear
echo ""
echo "EMPITY?????"
echo ""
sleep 3
block
else
clear
cat /etc/blockdragon/sites.cake | grep $website && site=1 || site=0
clear
if [ "$site" = "1" ]; then
clear
echo ""
echo ""
tput setaf 2 ; tput bold ; printf '%s' "|*|"; tput setaf 6 ; printf '%s' "already blocked Website: $website" ; tput setaf 2 ; tput bold ; printf '%s' "|*|"; echo ""
sleep 3
block
elif [ "$site" = "0" ]; then
sudo iptables -A INPUT -s $website -j DROP && sudo iptables -A FORWARD -s $website  -j DROP
echo "$website" >> /etc/blockdragon/sites.cake
echo "/etc/blockdragon/blocks/$website" >> /etc/blockdragon/dragon.block
echo "sudo iptables -A INPUT -s $website -j DROP && sudo iptables -A FORWARD -s $website  -j DROP" >> /etc/blockdragon/blocks/$website
chmod +x /etc/blockdragon/blocks/$website
clear
echo ""
echo ""
tput setaf 2 ; tput bold ; printf '%s' "|*|"; tput setaf 6 ; printf '%s' "Blocked Website: $website" ; tput setaf 2 ; tput bold ; printf '%s' "|*|"; echo ""
sleep 3
block
else
clear
echo "BROKEN"
sleep 3
block
fi
fi
elif [ "$option" = "2" ]; then
bmenu
else
clear
tput setaf 7 ; tput setab 4 ; tput bold ; printf '%30s%s%-10s\n' "ONLY 1 our 2" ; tput sgr0 ; echo ""
sleep 3
block
fi
}

unblock(){
clear
echo -e " ${yellow}          === • UNBLOCKER • ===" ; tput sgr0 ; echo ""
echo ""
tput setaf 2 ; tput bold ; printf '%s' "|1|"; tput setaf 6 ; printf '%s' " Unblock" ; echo ""
tput setaf 2 ; tput bold ; printf '%s' "|2|"; tput setaf 6 ; printf '%s' " Back to menu" ; echo ""
echo ""
echo "Select a Option" ; tput sgr0 ; echo ""
echo -n "> "
read option
if [ "$option" = "1" ]; then 
clear
echo ""
tput setaf 2 ; tput bold ; printf '%s' "[>]"; tput setaf 6 ; printf '%s' " Insert the Website" ; tput setaf 2 ; tput bold ; printf '%s' " ="; echo ""
echo ""
echo -n "> "
read website
if [ -z $website ]; then
clear
echo ""
echo "EMPITY?????"
echo ""
sleep 3
unblock
else
clear
cat /etc/blockdragon/sites.cake | grep $website && site=1 || site=0
clear
if [ "$site" = "0" ]; then
clear
echo ""
echo ""
tput setaf 2 ; tput bold ; printf '%s' "|*|"; tput setaf 6 ; printf '%s' "already unblocked Website: $website" ; tput setaf 2 ; tput bold ; printf '%s' "|*|"; echo ""
sleep 3
unblock
elif [ "$site" = "1" ]; then
sudo iptables -D INPUT -s $website -j DROP && sudo iptables -D FORWARD -s $website  -j DROP
sed --in-place "/$website/d" /etc/blockdragon/sites.cake
sed --in-place "/$website/d" /etc/blockdragon/dragon.block
rm -f /etc/blockdragon/blocks/$website
clear
echo ""
echo ""
tput setaf 2 ; tput bold ; printf '%s' "|*|"; tput setaf 6 ; printf '%s' "unblocked Website: $website" ; tput setaf 2 ; tput bold ; printf '%s' "|*|"; echo ""
sleep 3
unblock
else
clear
echo "BROKEN"
sleep 3
unblock
fi
fi
elif [ "$option" = "2" ]; then
bmenu
else
clear
tput setaf 7 ; tput setab 4 ; tput bold ; printf '%30s%s%-10s\n' "ONLY 1 our 2" ; tput sgr0 ; echo ""
sleep 3
unblock
fi
}

view()
{
clear
echo ""
echo -e " ${yellow}          === • SITE BLOCKED • ===" ; tput sgr0 ; echo ""
printf "${green}"
echo ""
cat /etc/blockdragon/sites.cake
printf "${white}"
echo ""
echo ""
echo "Press Enter to return" ; tput sgr0 ; echo ""
echo -n "> "
read cake
bmenu
}



unblockall()
{
FILE=/etc/blockdragon/sites.cake
if [ -f "$FILE" ]; then
clear
else
sudo touch /etc/blockdragon/sites.cake
fi
FILE2=/etc/blockdragon/dragon.block
if [ -f "$FILE2" ]; then
clear
else
sudo touch /etc/blockdragon/dragon.block
fi
if [ -d "$FILE4" ]; then
clear
else
sudo mkdir /etc/blockdragon/blocks
chmod 777 /etc/blockdragon/blocks
fi
clear
echo -e " ${yellow}          === • ALL UNBLOCKER • ===" ; tput sgr0 ; echo ""
echo ""
tput setaf 2 ; tput bold ; printf '%s' "|1|"; tput setaf 6 ; printf '%s' " UnblockALL" ; echo ""
tput setaf 2 ; tput bold ; printf '%s' "|2|"; tput setaf 6 ; printf '%s' " Back to menu" ; echo ""
echo ""
echo "Select a Option" ; tput sgr0 ; echo ""
echo -n "> "
read option
if [ "$option" = "1" ]; then 

echo "This gonna reset the IPTABLES !" ; tput sgr0 ; echo ""
echo "Continue?" ; tput sgr0 ; echo ""
echo "y/n" ; tput sgr0 ; echo ""
echo -n "> "
read option2
if [ "$option2" = "y" ]; then 
clear
sudo iptables -F 
echo "DONE" ; tput sgr0 ; echo ""
rm -f /etc/blockdragon/sites.cake
rm -f /etc/blockdragon/dragon.block
rm -f -r /etc/blockdragon/blocks/
sleep 3
unblockall
elif [ "$option2" = "n" ]; then 
unblockall
else
clear
tput setaf 7 ; tput setab 4 ; tput bold ; printf '%30s%s%-10s\n' "ONLY Y our N" ; tput sgr0 ; echo ""
sleep 3
unblockall
fi
elif [ "$option" = "2" ]; then 
bmenu
else
clear
tput setaf 7 ; tput setab 4 ; tput bold ; printf '%30s%s%-10s\n' "ONLY 1 our 2" ; tput sgr0 ; echo ""
sleep 3
unblockall
fi
}

reblockall()
{
chmod +x /etc/blockdragon/dragon.block
/etc/blockdragon/dragon.block
clear
tput setaf 2 ; tput bold ; printf '%s' "|*|"; tput setaf 6 ; printf '%s' " REBLOCKED LIST" ; tput setaf 2 ; tput bold ; printf '%s' "|*|"; echo ""
sleep 3
bmenu
}
mmenu() {
cd $HOME
bash /usr/local/bin/menu
}
bmenu

