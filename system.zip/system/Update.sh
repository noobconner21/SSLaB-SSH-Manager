wget https://github.com/noobconner21/SSH-Panel/raw/main/system.zip
unzip system
cd /etc/Sslablk/system
mv menu /usr/local/bin
mv Update.sh /usr/local/bin
wget -O speedtest-cli https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py
chmod +x ChangeUser.sh
chmod +x Adduser.sh
chmod +x Banner.sh
chmod +x Port.sh
chmod +x DelUser.sh
chmod +x Siteblocker.bash
chmod +x Userlist.sh
chmod +x RemoveScript.sh
chmod +x speedtest-cli
chmod +x torrent.sh
cd /usr/local/bin
chmod +x menu
chmod +x Update.sh
cd /etc/Sslablk
rm system.zip